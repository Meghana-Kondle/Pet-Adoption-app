from django.shortcuts import render, get_object_or_404
from .models import Pet
from django.template import engines # Updated import for debugging
from django.template.exceptions import TemplateDoesNotExist

# ... (adoption_list, lost_list, found_list views remain the same) ...
def adoption_list(request):
    # Fetch only pets that are 'FOR_ADOPTION'
    pets = Pet.objects.filter(status='FOR_ADOPTION')
    context = {
        'pets': pets,
        'page_title': 'Pets Available for Adoption'
    }
    # Render the pet_list.html template with the filtered pets
    return render(request, 'webapp/pet_list.html', context)

# View for the Lost Pets page
def lost_list(request):
    # Fetch only pets that are 'LOST'
    pets = Pet.objects.filter(status='LOST')
    context = {
        'pets': pets,
        'page_title': 'Lost Pets'
    }
    # Reuse the same template
    return render(request, 'webapp/pet_list.html', context)

# View for the Found Pets page
def found_list(request):
    # Fetch only pets that are 'FOUND'
    pets = Pet.objects.filter(status='FOUND')
    context = {
        'pets': pets,
        'page_title': 'Found Pets'
    }
    # Reuse the same template
    return render(request, 'webapp/pet_list.html', context)

# View for a single pet's detail page
def pet_detail(request, pet_id):
    # --- Start of Corrected Diagnostic Code ---
    print("\n" + "="*50)
    print("DEBUGGING: Checking Django's template search paths...")

    # This loop will print every single directory where Django is looking for templates.
    for engine in engines.all():
        if engine.app_dirs:
            from django.template.loaders.app_directories import get_app_template_dirs
            app_dirs = get_app_template_dirs('templates')
            print(f"Searching in APP_DIRS for engine '{engine.name}':")
            for d in app_dirs:
                print(f"  - {d}")

    print("="*50 + "\n")
    # --- End of Corrected Diagnostic Code ---

    pet = get_object_or_404(Pet, id=pet_id)
    context = {'pet': pet}

    try:
        return render(request, 'webapp/pet_detail.html', context)
    except TemplateDoesNotExist:
        print("\nERROR: The template 'webapp/pet_detail.html' could not be found in any of the paths listed above.")
        raise

