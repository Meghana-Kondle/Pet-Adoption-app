from django.urls import path
from . import views

# Add this line to define the application namespace
app_name = 'webapp'

urlpatterns = [
    # The paths and names are the same
    path('', views.adoption_list, name='adoption_list'),
    path('lost/', views.lost_list, name='lost_list'),
    path('found/', views.found_list, name='found_list'),
    path('pet/<int:pet_id>/', views.pet_detail, name='pet_detail'),
]

