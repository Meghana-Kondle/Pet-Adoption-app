from django.db import models

class Pet(models.Model):
    # --- Choices for the new status field ---
    STATUS_CHOICES = [
        ('FOR_ADOPTION', 'For Adoption'),
        ('LOST', 'Lost'),
        ('FOUND', 'Found'),
        ('ADOPTED', 'Adopted/Reunited'),
    ]

    SPECIES_CHOICES = [
        ('DOG', 'Dog'),
        ('CAT', 'Cat'),
        ('RABBIT', 'Rabbit'),
        ('OTHER', 'Other'),
    ]

    # --- Model Fields ---
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='FOR_ADOPTION')
    name = models.CharField(max_length=100)
    species = models.CharField(max_length=10, choices=SPECIES_CHOICES)
    breed = models.CharField(max_length=100, blank=True, null=True) # Optional field
    age = models.IntegerField(blank=True, null=True) # Optional field
    description = models.TextField()
    image = models.ImageField(upload_to='pet_images/')

    location = models.CharField(max_length=255, help_text="e.g., City, State or Neighborhood")
    contact_email = models.EmailField()

    def __str__(self):
        return f"{self.name} ({self.get_status_display()})"

