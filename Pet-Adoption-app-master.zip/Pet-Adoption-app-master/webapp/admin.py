from django.contrib import admin
from .models import Pet

# The @admin.register decorator is a clean way to register your model.
@admin.register(Pet)
class PetAdmin(admin.ModelAdmin):
    # This configures how the list of pets will look in the admin panel.
    # It makes the list more readable and adds useful filtering.
    list_display = ('name', 'status', 'species', 'location')
    list_filter = ('status', 'species')
    search_fields = ('name', 'location', 'description')

