# Pet Adoption App

This is a Django-based web application for pet adoption, enhanced with Streamlit for interactive data visualization and analytics.

## Features
- Django backend for managing pets and adoptions
- Streamlit integration for interactive dashboards and analytics
- Image upload and display for pets
- Admin interface for managing data

## Project Structure
```
home/
├── db.sqlite3
├── manage.py
├── home/
│   ├── settings.py
│   ├── urls.py
│   └── ...
├── webapp/
│   ├── models.py
│   ├── views.py
│   ├── templates/
│   ├── static/
│   └── ...
└── media/
    └── pet_images/
```

## Getting Started

### Prerequisites
- Python 3.10+
- pip

### Installation
1. Clone the repository:
   ```
   git clone https://github.com/Abhijit1018/Pet-Adoption-app.git
   cd Pet-Adoption-app
   ```
2. Install dependencies:
   ```
   pip install -r requirements.txt
   ```
3. Apply migrations:
   ```
   python manage.py migrate
   ```
4. Create a superuser (optional, for admin access):
   ```
   python manage.py createsuperuser
   ```
5. Run the Django server:
   ```
   python manage.py runserver
   ```
6. (Optional) Run the Streamlit app:
   ```
   streamlit run streamlit_app.py
   ```

## Streamlit Integration
- Place your Streamlit scripts (e.g., `streamlit_app.py`) in the project root or a dedicated folder.
- Use Streamlit for analytics, dashboards, or any interactive features you want to add.

## License
MIT

## Author
Abhijit1018
